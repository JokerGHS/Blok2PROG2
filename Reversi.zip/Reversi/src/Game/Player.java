package Game;

public class Player {
	
	private String name;
	private char stone;
	
	
	public char getStone() {
		return stone;
	}
	public void setStone(char stone) {
		this.stone = stone;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	

}
